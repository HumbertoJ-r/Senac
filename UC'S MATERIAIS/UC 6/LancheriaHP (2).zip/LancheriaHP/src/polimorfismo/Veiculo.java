package polimorfismo;

public interface Veiculo {
    void acelerar();
    void frear();
}
