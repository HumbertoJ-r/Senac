package projetolancheria;

import classes.Produto;


public class Main2 {
     public static void main(String[] args) {
         // Revisão
         
         // 👉 Tipo primitivo (variáveis) vs Referência (objetos)
         
         // Tipo primitivo
         String x; int y; float z; double a; boolean b;
         
         // Objeto => instancia de uma classe (que possui atributos e métodos)
         Produto p1 = new Produto();
         p1.setId(1);                    p1.getId();
         p1.setNome("Teste");           p1.getNome();
         
         // Encapsulamento, Getters e Setters, Construtores ✅
         
         
         
                 
         
     }
}
