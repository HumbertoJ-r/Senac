package projetolancheria;

import classes.Produto;

public class Main {
    public static void main(String[] args) {
        // Instanciando um objeto
        Produto produto1 = new Produto(1, "Xis", "Muitas calorias", 30.98);
        System.out.println(produto1.getId() + " - " + produto1.getNome() + ": " + produto1.getDescricao() + "(R$" + produto1.getValor() +")" );

        produto1.setNome("Xis bacon");
        System.out.println(produto1.getId() + " - " + produto1.getNome() + ": " + produto1.getDescricao() + "(R$" + produto1.getValor() +")" );
        
        Produto p2 = new Produto();

        // Classe, atributo, método
        //System.out.println(produto1.id);
        
        //Guardar valores na memória
        //produto1.atribuirValorEmId(3);
        /*
        produto1.nome = "Xis";
        produto1.descricao = "Muitas calorias";
        produto1.valor = 28.90;
        
        System.out.println(produto1.id + " - " + produto1.nome + ": " + produto1.descricao + " (R$ "+ produto1.valor+")");
        */
        
        //System.out.println(produto1.retornarOValor());
    }
    
}
